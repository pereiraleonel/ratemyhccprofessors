from django.apps import AppConfig


class RateprofessorsConfig(AppConfig):
    name = 'rateprofessors'
