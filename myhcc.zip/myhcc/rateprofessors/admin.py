from django.contrib import admin

from rateprofessors.models import Campus, College
# Register your models here.
admin.site.register(Campus)
admin.site.register(College)
